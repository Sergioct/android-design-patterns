package com.juangabrielgomila.sandwichbuilderpattern.ingredient;


/**
 * Created by JuanGabriel on 14/10/17.
 */

public interface Ingredient {

    public String description();

    public int kcal();

}
