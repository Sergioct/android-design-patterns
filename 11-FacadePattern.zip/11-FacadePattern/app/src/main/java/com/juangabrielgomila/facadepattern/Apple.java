package com.juangabrielgomila.facadepattern;

public class Apple implements Product{

    @Override
    public int dispense() {
        return R.drawable.apple;
    }
}

