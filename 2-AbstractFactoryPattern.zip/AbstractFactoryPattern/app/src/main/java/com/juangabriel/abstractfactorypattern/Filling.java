package com.juangabriel.abstractfactorypattern;

public interface Filling {
    String name();
    String calories();
}


