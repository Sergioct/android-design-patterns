package com.juangabrielgomila.builderpattern.builder;

/**
 * Created by JuanGabriel on 12/10/17.
 */

public interface Shading {
    int shade();
    int background();
}
