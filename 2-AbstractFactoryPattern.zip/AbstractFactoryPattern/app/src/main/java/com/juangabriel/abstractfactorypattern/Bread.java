package com.juangabriel.abstractfactorypattern;

/**
 * Created by JuanGabriel on 6/9/17.
 */

public interface Bread {
    String name();
    String calories();
}

