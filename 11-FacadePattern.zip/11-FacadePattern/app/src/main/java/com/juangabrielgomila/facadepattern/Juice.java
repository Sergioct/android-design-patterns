package com.juangabrielgomila.facadepattern;

public class Juice implements Product{

    @Override
    public int dispense() {
        return R.drawable.juice;
    }
}
