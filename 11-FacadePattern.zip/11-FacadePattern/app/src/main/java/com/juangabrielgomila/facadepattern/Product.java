package com.juangabrielgomila.facadepattern;

/**
 * Created by JuanGabriel on 8/10/17.
 */

public interface Product {

    int dispense();

}
