package com.juangabrielgomila.observerpattern;

/**
 * Created by JuanGabriel on 12/11/17.
 */

public interface Observer {

    String update();

}
