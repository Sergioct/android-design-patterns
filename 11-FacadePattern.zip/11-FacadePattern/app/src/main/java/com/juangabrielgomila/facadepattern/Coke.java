package com.juangabrielgomila.facadepattern;

public class Coke implements Product{

    @Override
    public int dispense() {
        return R.drawable.coke;
    }
}

