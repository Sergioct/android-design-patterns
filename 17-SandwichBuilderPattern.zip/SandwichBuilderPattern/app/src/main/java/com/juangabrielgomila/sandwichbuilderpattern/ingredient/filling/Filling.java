package com.juangabrielgomila.sandwichbuilderpattern.ingredient.filling;

import com.juangabrielgomila.sandwichbuilderpattern.ingredient.Ingredient;

/**
 * Created by JuanGabriel on 14/10/17.
 */

public abstract class Filling implements Ingredient {




}
