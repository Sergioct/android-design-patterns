package com.juangabriel.abstractfactorypattern;

/**
 * Created by JuanGabriel on 6/9/17.
 */

public interface Drink {
    String name();
    String calories();
}

