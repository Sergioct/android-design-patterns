package com.juangabrielgomila.weatherapp;

/**
 * Created by JuanGabriel on 7/12/17.
 */

public interface Strategy {

    String reportCurrentWeather();

}
