package com.juangabrielgomila.facadepattern;

/**
 * Created by JuanGabriel on 8/10/17.
 */

public class Crisps implements Product {

    @Override
    public int dispense() {
        return R.drawable.crisps;
    }
}

